import pygame
import sys


print (pygame.ver)

